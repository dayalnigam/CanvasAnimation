package com.example.graphicalapplications;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class MainActivity extends Activity {

    DemoView demoview;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        demoview = new DemoView(this);
        setContentView(demoview);
    }

    private class DemoView extends View{
        public DemoView(Context context){
            super(context);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            Paint paint = new Paint();
            paint.setStyle(Paint.Style.FILL);

            paint.setColor(Color.WHITE);
            canvas.drawPaint(paint);
            paint.setAntiAlias(false);
            paint.setColor(Color.BLUE);
            canvas.drawLine(400,120,450,300,paint);
            paint.setTextSize(30);
            canvas.drawText("Line", 390, 300, paint);

            paint.setAntiAlias(true);
            paint.setColor(Color.GREEN);
            canvas.drawCircle(100,240,90,paint);
            paint.setTextSize(30);
            canvas.drawText("Circle", 90, 360, paint);
            paint.setAntiAlias(false);
            paint.setColor(Color.RED);
            canvas.drawRect(50, 50, 150, 100, paint);
            paint.setTextSize(30);
            canvas.drawText("Rectangle", 90, 130, paint);
            paint.setColor(Color.BLACK);
            paint.setTextSize(40);
            canvas.drawText("Dayal Nigam Experiment :8", 20, 500, paint);
            canvas.drawText("Canvas drawing using", 20, 550, paint);
            canvas.drawText("Android Studio", 20, 600, paint);
            canvas.rotate(0);
            paint.setStyle(Paint.Style.FILL);
            canvas.save();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

}
